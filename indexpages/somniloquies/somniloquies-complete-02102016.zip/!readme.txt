This is a comprehensive archive of things I've said in my sleep, as recorded by Sleep as Android, since November 11, 2014 at 10:33:31.

Sounds are in format: Year Month Day - Hour Minute Second

You can reach me @ thnewlands@gmail.com
My website: http://thnewlands.com/
Here's the archive online: https://soundcloud.com/thnewlands/sets

Licensed under http://creativecommons.org/licenses/by/4.0/